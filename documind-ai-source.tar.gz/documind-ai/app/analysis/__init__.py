"""Paper analysis routines."""
