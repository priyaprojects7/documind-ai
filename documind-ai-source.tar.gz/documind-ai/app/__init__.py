"""DocuMind AI application package."""
