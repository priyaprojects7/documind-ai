"""Vector retrieval components."""
