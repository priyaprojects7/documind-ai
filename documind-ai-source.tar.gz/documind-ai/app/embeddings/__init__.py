"""Embedding model adapters."""
