"""PDF ingestion pipeline."""
